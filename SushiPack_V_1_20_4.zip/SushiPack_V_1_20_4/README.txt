Resources
=================
Video tutorial https://www.youtube.com/watch?v=Cw8PPPEl_IQ&t=994s
Texture Pack Original Creator: R4dele https://www.planetminecraft.com/texture-pack/sushi-4962277/

Changes I implemented
+++++++++++++++++
-Rearranged files
-Used give item command to get custom models
-Changed tamago's vanilla model and properties file item from potato to egg 
-Explicitly stated root folders in each json file.
-Capitalized first letter in name changes for consistency

Minecraft Command to receive each item:
/give @s minecraft:BASEGAMEID{CustomModelData:1}

Item guide:
================
Salmon models:

For califorinia roll enter: /give @s minecraft:salmon{CustomModelData:1}
For hosomaki roll enter: /give @s minecraft:salmon{CustomModelData:2}
For philadelphia roll enter: /give @s minecraft:salmon{CustomModelData:3}
For sake roll enter: /give @s minecraft:salmon{CustomModelData:4}


Cod models:
For tekkamaki roll enter: /give @s Minecraft:cod{CustomModelData:1}
For maguro enter: /give @s Minecraft:cod{CustomModelData:2}

Tropical fish model:
For obi roll enter: /give @s Minecraft:ebi{CustomModelData:1}

Egg model:
For tamale enter: /give @s Minecraft:egg{CustomModelData:1}


Original Item guide:
================

Sushi rolls:
california - salmon
hosomaki - salmon
philadelphia - salmon
tekkamaki - cod

Sushi:
sake - salmon
ebi - tropical fish
maguro - cod
tamago - egg (was potato)

Version With Anvil Name Change System
================

1) Make sure folders are SushiPack>assets>minecraft>optifine>cit
2) Most simple method: In cit folder make sure all files can be found. Move all file types into this one folder.
- in json file, for "0": and "particles": add the root folders before your_custom_content name variable
3) If you create individual folders you must be explicit in the your_custom_content.json file where the folder resides in.
- for example if previous method was used the following lines will show where the files are located:		
"0": "optifine/cit/california",
"particle": "optifine/cit/california"
- creating an additional folder for each item should be explicitly stated as:
"0": "optifine/cit/california_folder/california",
"particle": "optifine/cit/california_folder/california"
4) in properties files you most include both:
model=california.json
texture=california.png
For 3d custom models built with Block Bench
- if item is just a 2D texture change you will only have properties and pngs files
- omit the model line or you will have a object rendered without a texture.
5)nbt.display.Name=ipattern:california
Added ipattern: in front of all custom item names in properties files

Voila!



Version without Name Change System
================

Steps to update block bench resource packs that require optifine
================
1) Create Texture pack folder
-Sushipack
2) Copy generic pack.mcmeta file for current version (2.20.4)
-copy&paste pack.mcdata from any mod for current version of minecraft into resource folder
3) Create assets folder inside resource folder
4) Create minecraft folder
5)Create models and inside resource folder
4) Create minecraft folder
5) Create models and textures folder within minecraft folder
6) Create block and item folder within models folder
7) Create custom folder within block folder
8) Paste all json files into custom folder. For example:  itemname.json
YourCustomPack/assets/minecraft/models/block/custom/itemname.json
- in blockbench this is your model (java block/item model) file
- make sure block/custom/itemname is within the double quotes after "0": and "particle":
-all lines of code are syntax sensitive. Remember your commas and brackets.
9)Go back to assets/minecraft/models/item/ and paste your base game vanilla item.json files into this that you want to create a custom model for. Make sure it states "layer0":"item/cod" (currently works for 1.20.4
10) in the "overrides" array place lines of your custom model. Each custom model should have a preceding number and should be seperated by a comma. Make sure it indicates where the model is in eg: "model": block/custom/youritem
11) go back to assets/minecraft/textures and create block folder
12) create custom folder
13) paste all your texture images here (png files)

if you are refreshing within the game to reload the texture packs (restart gameplay) then press for mac (fn+f3+t)

Voila!
=====================
enjoy ^-^ !
